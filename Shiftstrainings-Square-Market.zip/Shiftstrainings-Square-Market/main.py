import discord
from discord.ext import commands
from discord.ui import Button, View
import json

from flask import Flask
from threading import Thread

app = Flask(__name__)

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host="0.0.0.0", port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()


# Bot setup
intents = discord.Intents.default()
intents.messages = True
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)

# Data opslag voor shifts en trainingen
shifts_data_file = "shifts_trainings.json"
try:
    with open(shifts_data_file, "r") as file:
        shifts_data = json.load(file)
except FileNotFoundError:
    shifts_data = {}

# Opslaan van shifts/trainingsdata
def save_shifts_data():
    with open(shifts_data_file, "w") as file:
        json.dump(shifts_data, file, indent=4)

# Start een shift
@bot.command()
async def startshift(ctx, host: discord.Member, duration: int, is_promotional: bool = False, co_host: discord.Member = None, helper: discord.Member = None):
    shift_id = f"shift_{ctx.message.id}"  # Unieke shift ID
    shift = {
        "host": host.mention,
        "co_host": co_host.mention if co_host else "None",
        "helper": helper.mention if helper else "None",
        "duration": duration,
        "is_promotional": is_promotional,
        "type": "shift",
        "creator": ctx.author.id  # De persoon die de shift heeft gestart
    }

    # Maak een bericht met visuele aankondigingen
    embed = discord.Embed(
        title="🔔 New Shift Starting Soon!",
        description=f"Hosted by: {host.mention}\nCo-Hosted by: {co_host.mention if co_host else 'None'}\nHelper: {helper.mention if helper else 'None'}\nDuration: {duration} minutes\nPromotional: {'Yes' if is_promotional else 'No'}\n\nThe shift starts now, start joining!",
        color=discord.Color.green()
    )
    embed.set_footer(text=f"Shift starts in {duration} minutes!")

    # Verzenden naar het kanaal waar het commando werd getypt
    message = await ctx.send(embed=embed)

    # Voeg de "End Shift" knop toe
    end_button = Button(label="End Shift", style=discord.ButtonStyle.danger)
    view = View()
    view.add_item(end_button)

    async def on_end_button_click(interaction):
        if interaction.user.id != shift["creator"]:
            await interaction.response.send_message("You are not authorized to end this shift.", ephemeral=True)
            return

        # Wijzig de kleur van het originele bericht naar rood
        await message.edit(embed=discord.Embed(
            title="❌ Shift Ended",
            description="This shift has ended.",
            color=discord.Color.red()  # Rood voor beëindiging
        ))

        # Bedank het team en stop de shift
        embed = discord.Embed(
            title="✅ Shift Completed!",
            description="Thank you for being present!",
            color=discord.Color.green()
        )

        # Verzenden naar het kanaal waar het commando werd getypt
        await ctx.send(embed=embed)

        # Logging in het #shifts-trainings-logs kanaal
        log_channel = discord.utils.get(ctx.guild.text_channels, name="shifts-trainings-logs")
        if log_channel:
            log_embed = discord.Embed(
                title="Shift Completed",
                description=f"Shift completed by {interaction.user.mention}\nHost: {host.mention}\nCo-host: {co_host.mention if co_host else 'None'}\nHelper: {helper.mention if helper else 'None'}\nDuration: {duration} minutes\nPromotional: {'Yes' if is_promotional else 'No'}",
                color=discord.Color.green()
            )
            await log_channel.send(embed=log_embed)

        # Verwijder de shift uit de data
        if shift_id in shifts_data:
            del shifts_data[shift_id]
        save_shifts_data()

    end_button.callback = on_end_button_click

    # Stuur de knop in het kanaal
    await message.edit(view=view)

    # Sla de shift op in de data
    shifts_data[shift_id] = shift
    save_shifts_data()

# Start een training
@bot.command()
async def starttraining(ctx, host: discord.Member, duration: int, co_host: discord.Member = None, helper: discord.Member = None):
    training_id = f"training_{ctx.message.id}"  # Unieke training ID
    training = {
        "host": host.mention,
        "co_host": co_host.mention if co_host else "None",
        "helper": helper.mention if helper else "None",
        "duration": duration,
        "type": "training",
        "creator": ctx.author.id  # De persoon die de training heeft gestart
    }

    # Maak een bericht met visuele aankondigingen
    embed = discord.Embed(
        title="🔔 New Training Starting Soon!",
        description=f"Hosted by: {host.mention}\nCo-Hosted by: {co_host.mention if co_host else 'None'}\nHelper: {helper.mention if helper else 'None'}\nDuration: {duration} minutes\n\nThe training starts now, start joining!",
        color=discord.Color.blue()
    )
    embed.set_footer(text=f"Training starts in {duration} minutes!")

    # Verzenden naar het kanaal waar het commando werd getypt
    message = await ctx.send(embed=embed)

    # Voeg de "End Training" knop toe
    end_button = Button(label="End Training", style=discord.ButtonStyle.danger)
    view = View()
    view.add_item(end_button)

    async def on_end_button_click(interaction):
        if interaction.user.id != training["creator"]:
            await interaction.response.send_message("You are not authorized to end this training.", ephemeral=True)
            return

        # Wijzig de kleur van het originele bericht naar rood
        await message.edit(embed=discord.Embed(
            title="❌ Training Ended",
            description="This training has ended.",
            color=discord.Color.red()  # Rood voor beëindiging
        ))

        # Bedank het team en stop de training
        embed = discord.Embed(
            title="✅ Training Completed!",
            description="Thank you for participating in the training!",
            color=discord.Color.blue()
        )

        # Verzenden naar het kanaal waar het commando werd getypt
        await ctx.send(embed=embed)

        # Logging in het #shifts-trainings-logs kanaal
        log_channel = discord.utils.get(ctx.guild.text_channels, name="shifts-trainings-logs")
        if log_channel:
            log_embed = discord.Embed(
                title="Training Completed",
                description=f"Training completed by {interaction.user.mention}\nHost: {host.mention}\nCo-host: {co_host.mention if co_host else 'None'}\nHelper: {helper.mention if helper else 'None'}\nDuration: {duration} minutes",
                color=discord.Color.blue()
            )
            await log_channel.send(embed=log_embed)

        # Verwijder de training uit de data
        if training_id in shifts_data:
            del shifts_data[training_id]
        save_shifts_data()

    end_button.callback = on_end_button_click

    # Stuur de knop in het kanaal
    await message.edit(view=view)

    # Sla de training op in de data
    shifts_data[training_id] = training
    save_shifts_data()


# Annuleer een shift
@bot.command()
async def cancelshift(ctx, *, reason: str):
    shift_id = f"shift_{ctx.message.id}"
    if shift_id in shifts_data:
        del shifts_data[shift_id]
        save_shifts_data()

        # Wijzig de kleur van het originele bericht naar rood
        await ctx.message.edit(embed=discord.Embed(
            title="❌ Shift Canceled",
            description=f"Shift has been canceled. Reason: {reason}",
            color=discord.Color.red()
        ))

        await ctx.send(f"The shift has been canceled for the following reason: {reason}")

        log_channel = discord.utils.get(ctx.guild.text_channels, name="shifts-trainings-logs")
        if log_channel:
            log_embed = discord.Embed(
                title="Shift Canceled",
                description=f"Shift canceled by {ctx.author.mention}\nReason: {reason}",
                color=discord.Color.red()
            )
            await log_channel.send(embed=log_embed)
    else:
        await ctx.send("No shift found to cancel.")

# Annuleer een training
@bot.command()
async def canceltraining(ctx, *, reason: str):
    training_id = f"training_{ctx.message.id}"
    if training_id in shifts_data:
        del shifts_data[training_id]
        save_shifts_data()

        # Wijzig de kleur van het originele bericht naar rood
        await ctx.message.edit(embed=discord.Embed(
            title="❌ Training Canceled",
            description=f"Training has been canceled. Reason: {reason}",
            color=discord.Color.red()
        ))

        await ctx.send(f"The training has been canceled for the following reason: {reason}")

        log_channel = discord.utils.get(ctx.guild.text_channels, name="shifts-trainings-logs")
        if log_channel:
            log_embed = discord.Embed(
                title="Training Canceled",
                description=f"Training canceled by {ctx.author.mention}\nReason: {reason}",
                color=discord.Color.red()
            )
            await log_channel.send(embed=log_embed)
    else:
        await ctx.send("No training found to cancel.")
keep_alive()
# Start de bot
bot.run("MTMyOTQ5NTQ0MTk2ODIwNTgzNA.G81UdR.Wbe-cWYNVNgUhjR954dRslFclFvfIL1-gJxX_Q")
